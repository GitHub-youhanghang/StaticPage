# H5-resume
简约系H5简历

>利用HTML5+CSS3的技术，采用组件化开发思想，建立H5个人简历


![图 1 预览图](/demoPic/1.png)

![图 2 预览图](/demoPic/2.png)

![图 3 预览图](/demoPic/3.png)